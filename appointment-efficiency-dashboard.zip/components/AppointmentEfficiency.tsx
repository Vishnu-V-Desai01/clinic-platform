'use client';

import React from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Inbox } from 'lucide-react';

export interface AppointmentEfficiencyProps {
  data?: {
    totalAppointments: number;
    sameDayBookings: number;
    advanceBookings: number;
    sameDayBookingRate: number; // 0–1
    repeatPatientAppointments: number;
    newPatientAppointments: number;
    repeatPatientRate: number; // 0–1
    cancellationReasons: Array<{
      reason: string;
      count: number;
    }>;
    busiestHours: Array<{
      hour: number;
      label: string;
      count: number;
    }>;
  };
}

const DEFAULT_DATA = {
  totalAppointments: 35,
  sameDayBookings: 12,
  advanceBookings: 23,
  sameDayBookingRate: 0.34,
  repeatPatientAppointments: 24,
  newPatientAppointments: 11,
  repeatPatientRate: 0.69,
  cancellationReasons: [
    { reason: 'Patient request', count: 8 },
    { reason: 'Doctor unavailable', count: 5 },
    { reason: 'Rescheduled', count: 4 },
    { reason: 'No reason given', count: 3 },
    { reason: 'Feeling better', count: 2 },
    { reason: 'Transport issue', count: 1 },
  ],
  busiestHours: [
    { hour: 9, label: '9 AM', count: 4 },
    { hour: 10, label: '10 AM', count: 6 },
    { hour: 11, label: '11 AM', count: 5 },
    { hour: 12, label: '12 PM', count: 3 },
    { hour: 14, label: '2 PM', count: 7 },
    { hour: 15, label: '3 PM', count: 6 },
    { hour: 16, label: '4 PM', count: 4 },
    { hour: 17, label: '5 PM', count: 2 },
  ],
};

const EmptyState = () => (
  <div className="flex flex-col items-center justify-center py-12 text-center">
    <Inbox className="mb-3 h-8 w-8 text-muted-foreground" />
    <p className="text-sm font-medium text-foreground mb-1">
      No data for this period
    </p>
    <p className="text-xs text-muted-foreground">
      Try widening the date range.
    </p>
  </div>
);

const StatCard = ({
  label,
  value,
  subtext,
}: {
  label: string;
  value: string;
  subtext: string;
}) => (
  <Card className="border border-border bg-card rounded-xl shadow-sm p-5">
    <p className="text-xs font-medium text-muted-foreground mb-2">{label}</p>
    <p className="text-2xl font-semibold text-foreground">{value}</p>
    <p className="text-xs text-muted-foreground mt-1">{subtext}</p>
  </Card>
);

const SplitBar = ({
  primary: { pct, label: primaryLabel },
  secondary: { pct: secondaryPct, label: secondaryLabel },
}: {
  primary: { pct: number; label: string };
  secondary: { pct: number; label: string };
}) => {
  const primaryPct = Math.round(pct * 100);
  const secondaryPct = 100 - primaryPct;

  return (
    <div className="mt-4">
      <div className="flex gap-2 rounded-full bg-background p-0.5 overflow-hidden h-2.5">
        <div
          className="bg-[#0E9384] rounded-full"
          style={{ width: `${primaryPct}%` }}
          aria-label={`${primaryLabel}: ${primaryPct}%`}
        />
        <div
          className="bg-muted rounded-full flex-1"
          aria-label={`${secondaryLabel}: ${secondaryPct}%`}
        />
      </div>
      <div className="flex gap-4 mt-2 text-xs text-muted-foreground">
        <div className="flex items-center gap-1">
          <div className="w-2 h-2 rounded-full bg-[#0E9384]" />
          <span>
            {primaryLabel} {primaryPct}%
          </span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-2 h-2 rounded-full bg-muted-foreground/50" />
          <span>
            {secondaryLabel} {secondaryPct}%
          </span>
        </div>
      </div>
    </div>
  );
};

export default function AppointmentEfficiency({
  data = DEFAULT_DATA,
}: AppointmentEfficiencyProps) {
  const displayData = data || DEFAULT_DATA;

  return (
    <div className="space-y-6">
      <h2 className="text-lg font-semibold text-foreground">
        Appointment Efficiency
      </h2>

      {/* Stats with Split Bars */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Same-Day Bookings */}
        <div>
          <StatCard
            label="Same-Day Bookings"
            value={`${Math.round(displayData.sameDayBookingRate * 100)}%`}
            subtext={`${displayData.sameDayBookings} of ${displayData.totalAppointments} appointments`}
          />
          <SplitBar
            primary={{
              pct: displayData.sameDayBookingRate,
              label: 'Same-day',
            }}
            secondary={{
              pct: 1 - displayData.sameDayBookingRate,
              label: 'Advance-booked',
            }}
          />
        </div>

        {/* Repeat Patients */}
        <div>
          <StatCard
            label="Repeat Patients"
            value={`${Math.round(displayData.repeatPatientRate * 100)}%`}
            subtext={`${displayData.repeatPatientAppointments} of ${displayData.totalAppointments} appointments`}
          />
          <SplitBar
            primary={{
              pct: displayData.repeatPatientRate,
              label: 'Repeat',
            }}
            secondary={{
              pct: 1 - displayData.repeatPatientRate,
              label: 'New',
            }}
          />
        </div>
      </div>

      {/* Cancellation Reasons & Busiest Time */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Cancellation Reasons */}
        <Card className="border border-border bg-card rounded-xl shadow-sm p-5">
          <h3 className="text-sm font-semibold text-foreground mb-4">
            Cancellation Reasons
          </h3>
          {displayData.cancellationReasons.length === 0 ? (
            <EmptyState />
          ) : (
            <div className="space-y-3">
              {displayData.cancellationReasons.slice(0, 8).map((item, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between text-sm"
                >
                  <span className="text-foreground">{item.reason}</span>
                  <Badge variant="secondary" className="bg-muted text-muted-foreground">
                    {item.count}
                  </Badge>
                </div>
              ))}
            </div>
          )}
        </Card>

        {/* Busiest Time of Day */}
        <Card className="border border-border bg-card rounded-xl shadow-sm p-5">
          <h3 className="text-sm font-semibold text-foreground mb-4">
            Busiest Time of Day
          </h3>
          {displayData.busiestHours.length === 0 ? (
            <EmptyState />
          ) : (
            <div className="text-muted-foreground">
              <ResponsiveContainer width="100%" height={240}>
                <BarChart data={displayData.busiestHours}>
                  <CartesianGrid
                    stroke="currentColor"
                    strokeOpacity={0.1}
                    strokeDasharray="3 3"
                    vertical={false}
                  />
                  <XAxis
                    dataKey="label"
                    stroke="currentColor"
                    strokeOpacity={0.5}
                    style={{ fontSize: '12px' }}
                  />
                  <YAxis
                    stroke="currentColor"
                    strokeOpacity={0.5}
                    style={{ fontSize: '12px' }}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'var(--color-card)',
                      border: '1px solid var(--color-border)',
                      borderRadius: '6px',
                      color: 'var(--color-foreground)',
                    }}
                    cursor={{ fill: 'currentColor', fillOpacity: 0.05 }}
                    formatter={(value) => [value, 'Appointments']}
                  />
                  <Bar
                    dataKey="count"
                    fill="#0E9384"
                    radius={[4, 4, 0, 0]}
                    isAnimationActive={false}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}

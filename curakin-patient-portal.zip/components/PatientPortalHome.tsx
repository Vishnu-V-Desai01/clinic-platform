import { useState } from 'react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import {
  Clipboard,
  Check,
  ChevronRight,
  Building2,
} from 'lucide-react'

interface FamilyPatientCard {
  id: string
  firstName: string
  lastName: string
  clinicName: string
  createdAt: string
}

interface Props {
  familyCode: string
  cards: FamilyPatientCard[]
  onCardClick: (patientId: string) => void
  firstName?: string
}

// Toggle to preview empty state: set to true to see "No clinic enrollments" message
const PREVIEW_EMPTY = false

export default function PatientPortalHome({
  familyCode,
  cards: initialCards,
  onCardClick,
  firstName,
}: Props) {
  const [copied, setCopied] = useState(false)
  const [copyTimeoutId, setCopyTimeoutId] = useState<NodeJS.Timeout | null>(null)

  const cards = PREVIEW_EMPTY ? [] : initialCards

  const handleCopyFamilyCode = async () => {
    // Clear any existing timeout to avoid stale timers
    if (copyTimeoutId) {
      clearTimeout(copyTimeoutId)
    }

    try {
      await navigator.clipboard.writeText(familyCode)
      setCopied(true)

      // Reset after 2 seconds
      const timeoutId = setTimeout(() => {
        setCopied(false)
        setCopyTimeoutId(null)
      }, 2000)

      setCopyTimeoutId(timeoutId)
    } catch (error) {
      console.error('Failed to copy family code:', error)
    }
  }

  const formatDate = (isoDate: string): string => {
    try {
      return new Intl.DateTimeFormat('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
      }).format(new Date(isoDate))
    } catch {
      return isoDate
    }
  }

  return (
    <main className="mx-auto max-w-4xl px-4 py-6">
      {/* Greeting Section */}
      <div className="mb-8">
        <h1 className="text-lg font-semibold text-foreground">
          Welcome back{firstName ? `, ${firstName}` : ''}
        </h1>
        <p className="text-sm text-muted-foreground">
          Your CURAKIN Patient Portal
        </p>
      </div>

      {/* Family ID Banner */}
      <Card className="mb-8 border border-primary/20 bg-primary/10 p-5 rounded-xl">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <p className="text-xs font-medium text-muted-foreground mb-2">
              Your Unique Family ID
            </p>
            <p className="font-mono text-xl font-semibold text-foreground tracking-wide">
              {familyCode}
            </p>
          </div>
          <Button
            onClick={handleCopyFamilyCode}
            variant="default"
            className="w-full sm:w-auto"
            aria-label={copied ? 'Copied!' : 'Copy family ID'}
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 mr-2" aria-hidden="true" />
                Copied!
              </>
            ) : (
              <>
                <Clipboard className="w-4 h-4 mr-2" aria-hidden="true" />
                Copy
              </>
            )}
          </Button>
          {/* Screen reader status announcement */}
          {copied && (
            <span
              className="sr-only"
              role="status"
              aria-live="polite"
            >
              Family ID copied to clipboard
            </span>
          )}
        </div>
      </Card>

      {/* My Clinics Section */}
      <div>
        <div className="mb-4">
          <h2 className="text-lg font-semibold text-foreground">My Clinics</h2>
          <p className="text-sm text-muted-foreground">
            Your registered patient cards across clinics
          </p>
        </div>

        {cards.length === 0 ? (
          /* Empty State */
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-muted/50">
              <Building2
                className="h-8 w-8 text-muted-foreground"
                aria-hidden="true"
              />
            </div>
            <h3 className="font-semibold text-foreground mb-2">
              No clinic enrollments yet
            </h3>
            <p className="max-w-xs text-sm text-muted-foreground">
              Your clinic will register you via email and link your account.
            </p>
          </div>
        ) : (
          /* Clinic Grid */
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {cards.map((card) => (
              <button
                key={card.id}
                onClick={() => onCardClick(card.id)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault()
                    onCardClick(card.id)
                  }
                }}
                className="text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 rounded-xl transition-all"
                aria-label={`Open ${card.clinicName} patient card`}
              >
                <Card className="h-full border border-border hover:border-primary rounded-xl p-4 cursor-pointer transition-colors">
                  <div className="flex items-start justify-between mb-3">
                    <h3 className="font-semibold text-lg text-primary">
                      {card.clinicName}
                    </h3>
                    <ChevronRight
                      className="h-5 w-5 text-muted-foreground flex-shrink-0"
                      aria-hidden="true"
                    />
                  </div>

                  <p className="text-sm text-muted-foreground mb-2">
                    {card.firstName} {card.lastName}
                  </p>

                  <p className="text-xs text-muted-foreground">
                    Registered {formatDate(card.createdAt)}
                  </p>
                </Card>
              </button>
            ))}
          </div>
        )}
      </div>
    </main>
  )
}
